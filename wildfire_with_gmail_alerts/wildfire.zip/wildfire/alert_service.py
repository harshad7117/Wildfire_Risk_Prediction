"""
Alerting module: sends wildfire alerts via Gmail SMTP
Supports normal email + SMS through carrier email-to-SMS gateways
"""

import os
import yaml
import smtplib
from email.mime.text import MIMEText
from datetime import datetime
import pandas as pd

CONFIG = "config.yaml"

def load_config():
    if not os.path.exists(CONFIG):
        raise FileNotFoundError("config.yaml not found.")
    with open(CONFIG, "r") as f:
        return yaml.safe_load(f)

def send_email_gmail(tolist, subject, body, cfg):
    from_email = cfg["gmail"]["from_email"]
    password = cfg["gmail"]["app_password"]

    msg = MIMEText(body)
    msg["Subject"] = subject
    msg["From"] = from_email
    msg["To"] = ", ".join(tolist)

    with smtplib.SMTP("smtp.gmail.com", 587) as server:
        server.starttls()
        server.login(from_email, password)
        server.sendmail(from_email, tolist, msg.as_string())
        print(f"✅ Alert sent to: {tolist}")

# 🔥 This is the function your app.py expects
def send_alert(lat, lon, probability):
    """
    Send alert via Email and SMS (using email-to-SMS gateways).
    """
    cfg = load_config()
    recipients_email = cfg.get("alerts", {}).get("recipients", {}).get("email", [])
    recipients_sms = cfg.get("alerts", {}).get("recipients", {}).get("sms", [])

    all_recipients = recipients_email + recipients_sms
    if not all_recipients:
        print("⚠️ No recipients defined in config.yaml")
        return

    subject = "🚨 Wildfire High Risk Alert"
    body = (
        f"ALERT: High Risk of Wildfire Detected!\n\n"
        f"Location: Latitude {lat:.2f}, Longitude {lon:.2f}\n"
        f"Risk Probability: {probability:.2f}\n\n"
        "Please take immediate precautions."
    )

    send_email_gmail(all_recipients, subject, body, cfg)


# Optional: batch mode for saved predictions
def run_alerts():
    PRED_PATH = "data/processed/features_with_shap.parquet"
    if not os.path.exists(PRED_PATH):
        print("Predictions not found:", PRED_PATH)
        return

    cfg = load_config()
    df = pd.read_parquet(PRED_PATH)
    df['date'] = pd.to_datetime(df['date']).dt.date
    today = datetime.utcnow().date()
    df_today = df[df['date'] == today]
    if df_today.empty:
        print("No predictions for today:", today)
        return

    thr = cfg.get("alerts", {}).get("threshold", 0.6)
    high = df_today[df_today['prob'] >= thr]
    if high.empty:
        print("No high-risk zones today.")
        return

    msg = f"[Wildfire Alert] {len(high)} high-risk zones detected on {today}. Please take precautions."
    recipients = cfg.get("alerts", {}).get("recipients", {}).get("email", [])
    if recipients:
        send_email_gmail(recipients, "🔥 Wildfire Alert", msg, cfg)

if __name__ == "__main__":
    run_alerts()
