import streamlit as st
import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
import folium
from streamlit_folium import st_folium
import base64
import alert_service
import os
from datetime import datetime
from weather_api import get_live_weather

# ---------------- PAGE CONFIG ----------------
st.set_page_config(page_title="Wildfire Risk Dashboard", page_icon="🔥", layout="wide")

# ---------------- BACKGROUND FUNCTION ----------------
def set_bg(image_file):
    img_path = os.path.join(os.path.dirname(__file__), image_file)
    if not os.path.exists(img_path):
        st.warning(f"⚠️ Background image '{image_file}' not found.")
        return
    with open(img_path, "rb") as f:
        encoded = base64.b64encode(f.read()).decode()
    css = f"""
    <style>
    .stApp {{
        background-image: url("data:image/png;base64,{encoded}");
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
    }}
    </style>
    """
    st.markdown(css, unsafe_allow_html=True)

# ---------------- CUSTOM STYLES ----------------
st.markdown("""
    <style>
    .stButton > button {
        padding: 10px 20px;
        font-size: 16px;
        font-weight: bold;
        color: white;
        background-color: #1d3557;
        border-radius: 8px;
        border: none;
        transition: 0.3s;
    }
    .stButton > button:hover {
        background-color: #457b9d;
        transform: scale(1.05);
    }
    .stButton > button:active {
        background-color: #e63946 !important;
    }
    .title-panel {
        background: rgba(0, 0, 0, 0.6);
        padding: 15px;
        border-radius: 12px;
        text-align: center;
        margin-bottom: 30px;
    }
    .content-panel {
        background: rgba(0, 0, 0, 0.55);
        padding: 25px;
        border-radius: 15px;
        color: #f1faee;
        max-width: 850px;
        margin: auto;
        font-size: 18px;
        line-height: 1.6;
    }
    .alert-high {
        background: rgba(255, 0, 0, 0.85);
        color: white;
        font-size: 22px;
        font-weight: bold;
        text-align: center;
        padding: 20px;
        border-radius: 10px;
        margin-top: 20px;
        animation: blink 1s infinite alternate;
    }
    @keyframes blink {
        from { background-color: rgba(255, 0, 0, 0.8); }
        to { background-color: rgba(255, 100, 0, 1); }
    }
    </style>
""", unsafe_allow_html=True)

# ---------------- SESSION STATE ----------------
if "page" not in st.session_state:
    st.session_state.page = "home"

# ---------------- HISTORY ----------------
HISTORY_FILE = "history.csv"

def save_history(lat, lon, temp, hum, wind, veg, probability, risk_label):
    entry = {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "latitude": lat,
        "longitude": lon,
        "temperature": temp,
        "humidity": hum,
        "wind_speed": wind,
        "vegetation_index": veg,
        "probability": probability,
        "risk_label": risk_label
    }
    if os.path.exists(HISTORY_FILE):
        df = pd.read_csv(HISTORY_FILE)
        df = pd.concat([df, pd.DataFrame([entry])], ignore_index=True)
    else:
        df = pd.DataFrame([entry])
    df.to_csv(HISTORY_FILE, index=False)

def load_history():
    if os.path.exists(HISTORY_FILE):
        return pd.read_csv(HISTORY_FILE)
    return pd.DataFrame()

# ---------------- SIDEBAR ----------------
st.sidebar.markdown("## 🔥 Wildfire Dashboard")

def sidebar_button(label, key, page_name):
    if st.sidebar.button(label, key=key, use_container_width=True):
        st.session_state.page = page_name

sidebar_button("🏠 Home", "home", "home")
sidebar_button("📂 Upload Dataset", "upload", "upload")
sidebar_button("🌍 Predict Risk", "predict", "predict")
sidebar_button("🗺 Risk Map", "map", "map")
sidebar_button("📈 History", "history", "history")

# ---------------- PAGES ----------------
if st.session_state.page == "home":
    set_bg("background1.png")
    st.markdown("""
        <div class="title-panel">
            <h1 style='color:#f1faee; font-size:40px;'>🔥 Wildfire Risk Prediction Dashboard</h1>
        </div>
    """, unsafe_allow_html=True)
    st.markdown("""
        <div class="content-panel">
            <h2>👋 Welcome!</h2>
            <p>This dashboard predicts <b>wildfire risks</b> using uploaded datasets or live weather data.</p>
            <ul>
                <li>📂 Upload Dataset → Train a wildfire prediction model</li>
                <li>🌍 Predict Risk → Estimate wildfire probability for a location</li>
                <li>🗺 Risk Map → Visualize hotspots on an interactive map</li>
                <li>📈 History → Track predictions over time</li>
            </ul>
        </div>
    """, unsafe_allow_html=True)

elif st.session_state.page == "upload":
    st.markdown("## 📂 Upload Dataset")
    uploaded_file = st.file_uploader("Upload wildfire dataset (CSV)", type=["csv"])
    if uploaded_file:
        df = pd.read_csv(uploaded_file)
        st.write("📄 Preview:")
        st.dataframe(df.head())
        try:
            X = df[["temperature", "humidity", "wind_speed", "vegetation_index", "latitude", "longitude"]]
            y = df["fire_occurred"]
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)
            model = RandomForestClassifier(n_estimators=50, random_state=42)
            model.fit(X_train, y_train)
            acc = accuracy_score(y_test, model.predict(X_test))
            st.success(f"✅ Model trained successfully! Accuracy: {acc:.2f}")
            joblib.dump(model, "wildfire_model.pkl")
            df.to_csv("uploaded_dataset.csv", index=False)
        except Exception as e:
            st.error(f"⚠️ Dataset must contain required columns. Error: {e}")

elif st.session_state.page == "predict":
    st.markdown("## 🌍 Predict Wildfire Risk")

    lat = st.number_input("Latitude", 10.0, 40.0, 19.0)
    lon = st.number_input("Longitude", 60.0, 90.0, 73.0)

    # --- Live weather option ---
    use_live_weather = st.checkbox("🌦️ Use Live Weather Data")

    # Initialize weather values
    temp, hum, wind = 35, 40, 15
    veg = 0.7

    if use_live_weather:
        weather = get_live_weather(lat, lon)
        if weather:
            temp = weather["temperature"]
            hum = weather["humidity"]
            wind = weather["wind_speed"]
            st.success(f"✅ Live weather fetched: {temp:.1f}°C | {hum}% humidity | {wind:.1f} km/h wind")
        else:
            st.error("⚠️ Could not fetch live weather. Please check API key or internet connection.")

    temp = st.number_input("Temperature (°C)", 20, 50, int(temp))
    hum = st.number_input("Humidity (%)", 0, 100, int(hum))
    wind = st.number_input("Wind Speed (km/h)", 0, 50, int(wind))
    veg = st.number_input("Vegetation Index (0-1)", 0.0, 1.0, veg)

    # Centered Predict button
    st.markdown("<br>", unsafe_allow_html=True)
    col1, col2, col3 = st.columns([1, 1, 1])
    with col2:
        predict_clicked = st.button("🔮 Predict Risk", use_container_width=True)

    if predict_clicked:
        try:
            model = joblib.load("wildfire_model.pkl")
            new_data = pd.DataFrame([{
                "temperature": temp,
                "humidity": hum,
                "wind_speed": wind,
                "vegetation_index": veg,
                "latitude": lat,
                "longitude": lon
            }])
            probability = model.predict_proba(new_data)[0][1]
            risk_label = "🔥 HIGH RISK" if probability >= 0.7 else "🟢 LOW / MODERATE RISK"
            st.success(f"Prediction: {risk_label} | Probability: {probability:.2f}")

            save_history(lat, lon, temp, hum, wind, veg, probability, risk_label)

            if probability >= 0.7:
                st.markdown("""
                    <div class="alert-high">
                        🚨 <b>ALERT:</b> High Wildfire Risk Detected! Sending Email Alerts... 🔥
                    </div>
                """, unsafe_allow_html=True)
                try:
                    alert_service.send_alert(lat, lon, probability)
                    st.info("📧 Email alert sent successfully!")
                except Exception as e:
                    st.error(f"⚠️ Failed to send email alert: {e}")
        except Exception as e:
            st.error(f"⚠️ Please train model first in 'Upload Dataset' section. Error: {e}")

elif st.session_state.page == "map":
    st.markdown("## 🗺 Wildfire Risk Map")
    try:
        df = pd.read_csv("uploaded_dataset.csv")
        wildfire_map = folium.Map(location=[19, 73], zoom_start=5)
        for _, row in df.iterrows():
            color = "red" if row['fire_occurred'] == 1 else "green"
            folium.CircleMarker(
                location=[row['latitude'], row['longitude']],
                radius=6,
                color=color,
                fill=True,
                fill_color=color,
                popup=f"Fire: {row['fire_occurred']}"
            ).add_to(wildfire_map)
        st_folium(wildfire_map, width=1200, height=500)
    except:
        st.info("ℹ️ Upload dataset first in 'Upload Dataset' section.")

elif st.session_state.page == "history":
    st.markdown("## 📈 Prediction History")
    history = load_history()
    if not history.empty:
        st.dataframe(history)
        st.download_button("📥 Download History CSV", history.to_csv(index=False), "history.csv", "text/csv")
    else:
        st.info("⚠️ No predictions saved yet.")
